import os
import sys
import ctypes
import subprocess
import string
import re
from pathlib import Path

# WinAPI colors for cmd
if os.name == 'nt':
    STD_OUTPUT_HANDLE = -11
    handle = ctypes.windll.kernel32.GetStdHandle(STD_OUTPUT_HANDLE)

    def set_color(color):
        ctypes.windll.kernel32.SetConsoleTextAttribute(handle, color)

    CYAN = 12
    WHITE = 7
    LIGHT_GREEN = 10
    LIGHT_RED = 12
    LIGHT_YELLOW = 14
else:
    CYAN = WHITE = LIGHT_GREEN = LIGHT_RED = LIGHT_YELLOW = ''

CONFIG_FILE = Path(os.path.expanduser("~")) / ".no_update_mcbe_config.txt"

current_gdk_path = None
gdk_version = "не найден"

def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

def run_as_admin():
    if is_admin():
        return
    params = ' '.join([f'"{arg}"' for arg in sys.argv[1:]]) if sys.argv[1:] else ''
    ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, f'"{sys.argv[0]}" {params}', None, 1)
    sys.exit(0)

run_as_admin()  # само поднимает права

def auto_install_once():
    if CONFIG_FILE.exists():
        return
    set_color(LIGHT_YELLOW)
    print("[i] Первый запуск: устанавливаю зависимости...")
    set_color(WHITE)
    try:
        __import__("win32com")
    except ImportError:
        os.system(f'{sys.executable} -m pip install pywin32')
    CONFIG_FILE.touch()
    set_color(LIGHT_GREEN)
    print("[+] Зависимости установлены.")
    set_color(WHITE)

def print_big_title():
    set_color(CYAN)
    print("\n     ███╗   ██╗ ██████╗     ██╗   ██╗██████╗ ██████╗  █████╗ ████████╗███████╗")
    print("     ████╗  ██║██╔═══██╗    ██║   ██║██╔══██╗██╔══██╗██╔══██╗╚══██╔══╝██╔════╝")
    print("     ██╔██╗ ██║██║   ██║    ██║   ██║██████╔╝██║  ██║███████║   ██║   █████╗  ")
    print("     ██║╚██╗██║██║   ██║    ██║   ██║██╔═══╝ ██║  ██║██╔══██║   ██║   ██╔══╝  ")
    print("     ██║ ╚████║╚██████╔╝    ╚██████╔╝██║     ██████╔╝██║  ██║   ██║   ███████╗")
    print("     ╚═╝  ╚═══╝ ╚═════╝      ╚═════╝ ╚═╝     ╚═════╝ ╚═╝  ╚═╝   ╚═╝   ╚══════╝")
    set_color(WHITE)
    print()

def run_sc_command(command):
    result = os.system(command)
    if result != 0:
        set_color(LIGHT_RED)
        print(f"[!] Ошибка при выполнении: {command}")
        set_color(WHITE)
        return False
    return True

def block_updates_via_service():
    set_color(LIGHT_YELLOW)
    print("[i] Отключение службы InstallService (блочит обновления APPX + GDK)...")
    set_color(WHITE)
    if not run_sc_command("sc stop InstallService"):
        return
    if not run_sc_command("sc config InstallService start= disabled"):
        return
    set_color(LIGHT_GREEN)
    print("[#] Служба отключена. Обновления для APPX и GDK заблокированы!")
    set_color(WHITE)

def enable_updates_via_service():
    set_color(LIGHT_YELLOW)
    print("[i] Включение службы InstallService...")
    set_color(WHITE)
    if not run_sc_command("sc config InstallService start= demand"):
        return
    if not run_sc_command("sc start InstallService"):
        return
    set_color(LIGHT_GREEN)
    print("[#] Служба включена. Обновления разрешены.")
    set_color(WHITE)

def select_folder_dialog():
    ps_script = """
    Add-Type -AssemblyName System.Windows.Forms
    $folder = [System.Windows.Forms.FolderBrowserDialog]::new()
    $folder.Description = "Выберите папку Content (где лежит Minecraft.Windows.exe)"
    $folder.ShowNewFolderButton = $false
    if ($folder.ShowDialog() -eq "OK") { $folder.SelectedPath }
    """
    try:
        result = subprocess.check_output(["powershell", "-Command", ps_script], text=True, encoding="utf-8", errors="replace").strip()
        return Path(result) if result else None
    except Exception:
        set_color(LIGHT_RED)
        print("[!] Ошибка открытия диалога.")
        set_color(WHITE)
        return None

def ask_yes_no():
    while True:
        answer = input("Хотите выбрать папку вручную? (y/n): ").strip().lower()
        if answer in ['y', 'yes', 'д', 'да']:
            return True
        elif answer in ['n', 'no', 'н', 'нет']:
            return False
        else:
            set_color(LIGHT_RED)
            print("[!] Введите только y или n (или да/нет).")
            set_color(WHITE)

def get_gdk_version(path):
    config_file = path / "MicrosoftGame.config"
    if not config_file.exists():
        return "неизвестно"
    try:
        with open(config_file, "r", encoding="utf-8") as f:
            content = f.read()
        match = re.search(r'Version="(\d+\.\d+\.\d+)\d*\.\d+"', content)
        if match:
            return match.group(1)
        return "неизвестно"
    except:
        return "неизвестно"

def get_appx_version():
    try:
        result = subprocess.check_output(["powershell", "-Command", "Get-AppxPackage *Minecraft* | Select-Object -ExpandProperty Version"], text=True).strip()
        if result:
            parts = result.split('.')
            if len(parts) >= 3:
                return '.'.join(parts[:3])
        return "не установлено"
    except:
        return "неизвестно"

def find_or_ask_gdk_path():
    global current_gdk_path, gdk_version

    if current_gdk_path:
        return current_gdk_path

    drives = [f"{d}:\\" for d in string.ascii_uppercase if os.path.exists(f"{d}:\\")]
    for drive in drives:
        p = Path(drive) / "XboxGames" / "Minecraft for Windows" / "Content"
        if (p / "Minecraft.Windows.exe").exists() or (p / "Minecraft.Windows1.exe").exists():
            current_gdk_path = p
            gdk_version = get_gdk_version(p)
            return p

    set_color(LIGHT_YELLOW)
    print("[!] Путь к GDK не найден.")
    set_color(WHITE)

    if not ask_yes_no():
        print("[i] Отмена выбора пути.")
        gdk_version = "путь не найден"
        return None

    selected_path = select_folder_dialog()

    if not selected_path:
        print("[i] Выбор отменён.")
        gdk_version = "путь не найден"
        return None

    if (selected_path / "Minecraft.Windows.exe").exists() or (selected_path / "Minecraft.Windows1.exe").exists():
        current_gdk_path = selected_path
        gdk_version = get_gdk_version(selected_path)
        return selected_path

    set_color(LIGHT_RED)
    print("[!] В выбранной папке нет нужного exe.")
    set_color(WHITE)
    gdk_version = "путь не найден"
    return None

def create_shortcut(target, shortcut_path, icon):
    try:
        import win32com.client
        shell = win32com.client.Dispatch("WScript.Shell")
        shortcut = shell.CreateShortCut(str(shortcut_path))
        shortcut.Targetpath = str(target)
        if icon.exists():
            shortcut.IconLocation = str(icon)
        shortcut.save()
        return True
    except:
        return False

def gdk_block_update(p):
    orig = p / "Minecraft.Windows.exe"
    ren = p / "Minecraft.Windows1.exe"
    icon = p / "minecraftIcon.ico"
    desktop = Path(os.path.expanduser("~")) / "Desktop"
    lnk = desktop / "Minecraft for Windows.lnk"

    set_color(LIGHT_YELLOW)
    print(f"[i] Путь к установке: {p}")
    set_color(WHITE)
    if ren.exists():
        set_color(LIGHT_GREEN)
        print("[#] Обновление уже заблокировано (Minecraft.Windows1.exe)")
        set_color(WHITE)
        return
    os.rename(orig, ren)
    set_color(LIGHT_GREEN)
    print("[+] Переименовано в Minecraft.Windows1.exe (+быстрый запуск и мультиокна)")
    if create_shortcut(ren, lnk, icon):
        print("[+] Ярлык создан на рабочем столе")
    else:
        set_color(LIGHT_YELLOW)
        print("[!] Ярлык не создан")
        set_color(WHITE)
    print("[#] Блокировка обновлений выполнена.")
    set_color(WHITE)

def gdk_rollback(p):
    orig = p / "Minecraft.Windows.exe"
    ren = p / "Minecraft.Windows1.exe"
    lnk = Path(os.path.expanduser("~")) / "Desktop" / "Minecraft for Windows.lnk"

    set_color(LIGHT_YELLOW)
    print(f"[i] Путь к установке: {p}")
    set_color(WHITE)
    if not ren.exists():
        set_color(LIGHT_GREEN)
        print("[#] Обновление не заблокировано.")
        set_color(WHITE)
        return True
    if orig.exists():
        os.remove(orig)
    os.rename(ren, orig)
    set_color(LIGHT_GREEN)
    print("[+] Возвращено оригинальное имя")
    if lnk.exists():
        os.remove(lnk)
        print("[+] Ярлык удалён")
    print("[#] Откат выполнен.")
    set_color(WHITE)
    return True

def appx_manual_instruction():
    os.system('cls')
    print_big_title()
    set_color(LIGHT_YELLOW)
    print("Блокировка обновлений APPX (костыль, ручками, 50/50)")
    set_color(WHITE)
    print("\nАвтоматически это не сделать ибо защита папки WindowsApps слишком ахуевшая (ну или же я глупый)")
    print("Лучше всего юзай опцию [1] (служба InstallService) — она блочит обновы APPX + GDK надёжно и без гемора.")
    print("Если всё же хочешь костыль (работает в 80% случаев, но слетает после обновы GamingServices):")
    print("\n")
    print("1. Включи отображение скрытых файлов и папок:")
    print("   Проводник → Вид → Показать → галочка \"Скрытые элементы\".")
    print("2. Скачай IObit Unlocker (бесплатный, официальный сайт iobit.com или гугли \"IObit Unlocker download\").")
    print("3. Запусти Unlocker от имени администратора (правой кнопкой → Запуск от админа).")
    print("4. В Unlocker нажми \"Add\" перейди в:")
    print("   C:\\Program Files\\WindowsApps\\")
    print("5. Найди папку Microsoft.GamingServices_33.108.12001.0_x64__8wekyb3d8bbwe")
    print("   Если папки нет — обнови \"Игровые службы\" в Microsoft Store, потом найди заново.")
    print("6. Внутри найди gamingservicesnet.exe → выдели его.")
    print("7. Внизу выбери действие \"Unlock & Rename\".")
    print("   В поле нового имени введи: gamingservicesnet1.exe")
    print("   После apply, и Unlock & Rename сверху справа")
    print("9. Теперь создай пустой файл:")
    print("   Переименуй в \"gamingservicesnet.exe\" без txt в конце и тд.")
    print("10. Перетащи этот пустой gamingservicesnet.exe в Unlocker → выбери \"Unlock & Move\" → укажи ту же папку GamingServices из пункта 5 → Apply.")
    print("\nГотово: теперь в папке должны быть gamingservicesnet.exe (пустой) и gamingservicesnet1.exe (оригинал).")
    print("Обновы APPX должны стопорнуться.")
    print("\nОткат:")
    print("- Unlocker'ом разблокируй и удали пустой gamingservicesnet.exe")
    print("- Переименуй gamingservicesnet1.exe обратно в gamingservicesnet.exe")
    input("\nНажми Enter для возврата в меню...")

def rollback_menu():
    while True:
        os.system('cls')
        print_big_title()
        print("Панель отката:")
        print("[1] - Откат переименования GDK")
        print("[2] - Включить службу обновлений (APPX+GDK)")
        print("[0] - Выход в главное меню")
        c = input("\nВыберите действие: ").strip()
        if c == "1":
            path = find_or_ask_gdk_path()
            if path:
                if gdk_rollback(path):
                    input("\nНажмите Enter для возврата в главное меню...")
                    return
            else:
                set_color(LIGHT_YELLOW)
                print("[i] Откат переименования отменён.")
                set_color(WHITE)
            input("\nНажмите Enter для продолжения...")
        elif c == "2":
            enable_updates_via_service()
            input("\nНажмите Enter для возврата в главное меню...")
            return
        elif c == "0":
            return

def about_program():
    global gdk_version
    appx_version = get_appx_version()

    if gdk_version == "не найден":
        temp_path = find_or_ask_gdk_path()
        if temp_path:
            gdk_version = get_gdk_version(temp_path)
        else:
            gdk_version = "путь не найден"

    os.system('cls')
    print_big_title()
    set_color(CYAN)
    print("[v] Версия 5.7")
    set_color(WHITE)
    print("Эта программа предназначена для временной блокировки")
    print("Автоматических обновлений Minecraft Bedrock Edition.")
    print("Метод не гарантирует 100% защиту от обновлений в будущем.")
    print("Это экспериментальный подход.")
    print("Способы обхода взяты из открытых источников, кроме 2 варианта.")
    print("Телеграмм создателя @xLyouLx")
    print()
    print(f"GDK: {gdk_version}")
    print(f"APPX: {appx_version}")
    print("\nНажмите Enter для возврата...")
    input()

def main_menu():
    while True:
        os.system('cls')
        print_big_title()
        print("Панель выбора:")
        print("[1] - Блокировка обновлений через службу InstallService (APPX + GDK)")
        print("[2] - Блокировка обновлений переименованием (GDK) (+быстрый запуск и мультиокна)")
        print("[3] - Блокировка обновлений APPX (руками, костыль, 50/50)")
        print("[4] - Откат изменений")
        print("[5] - О программе")
        print("[0] - Выйти")
        choice = input("\nВыберите действие: ").strip()
        if choice == "1":
            block_updates_via_service()
            input("\nНажмите Enter...")
        elif choice == "2":
            path = find_or_ask_gdk_path()
            if path:
                gdk_block_update(path)
            else:
                set_color(LIGHT_YELLOW)
                print("[i] Блокировка GDK отменена.")
                set_color(WHITE)
            input("\nНажмите Enter...")
        elif choice == "3":
            appx_manual_instruction()
        elif choice == "4":
            rollback_menu()
        elif choice == "5":
            about_program()
        elif choice == "0":
            break

if __name__ == "__main__":
    auto_install_once()
    main_menu()